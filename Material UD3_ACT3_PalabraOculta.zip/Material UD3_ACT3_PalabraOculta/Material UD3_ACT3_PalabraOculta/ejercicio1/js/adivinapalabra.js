function generarPalabra() {
    let palabras = ["cocodrilo", "coche", "platano", "farola", "edificio", "sol", "movil"];
    let seleccion = palabras[getRandomInt(palabras.length)];
    return seleccion;
}
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}