window.addEventListener("load", function () {
    let bSolucion = this.document.getElementById("solucion");
    let bNueva = this.document.getElementById("nueva");
    let bFinalizar = this.document.getElementById("finalizar");
    let letras = this.document.getElementById("letras");
    let pal = this.document.getElementById("palabra");
    let result = document.getElementById("resultado");
    let porcentaje = document.getElementById("porcentaje");
    let letrasUsadas = [];
    let generado = "";

    function borrar() {
        while (result.firstChild) {
            result.removeChild(result.firstChild);
        }
    }
    function inicial() {
        bNueva.disabled = false;
        bSolucion.disabled = true;
        bFinalizar.disabled = true;
    }
    function limpiar() {
        letras.value = "";
        pal.value = "";
    }


    letras.addEventListener("input", function () {
        letras.value = letras.value.toUpperCase();
    });

    pal.addEventListener("input", function () {
        pal.value = pal.value.toUpperCase();
    });

    bNueva.addEventListener("click", function () {
        generado = generarPalabra();
        bNueva.disabled = true;
        bSolucion.disabled = false;
        bFinalizar.disabled = false;
        limpiar();
    });

    bFinalizar.addEventListener("click", function () {
        borrar();
        if (!pal.value == "") {
            let victoria = document.createElement("p");
            if (pal.value == generado.toUpperCase()) {
                victoria.innerHTML = "Ganaste";
                result.append(victoria);
                inicial();
                limpiar();
            } else {
                victoria.innerHTML = "Perdiste";
                result.append(victoria);
                inicial();
                limpiar();
            }
        } else {
            if (letras.value.length == 1) {
                if (generado.includes(letras.value)) {
                    letrasUsadas.push("Acierto: " + letras.value);
                } else {
                    letrasUsadas.push("Fallo: " + letras.value);
                }
                result.append(letrasUsadas.join("----"));
            }
        }


    });

    bSolucion.addEventListener("click", function () {
        borrar();
        let palabra = document.createElement("p");

        palabra.innerHTML = generado;
        result.append(palabra);
    });
});